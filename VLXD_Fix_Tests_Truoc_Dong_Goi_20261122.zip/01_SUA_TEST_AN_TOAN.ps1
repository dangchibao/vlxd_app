param(
    [string]$ProjectRoot = 'D:\app\vlxd_app'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$testDir = Join-Path $ProjectRoot 'test'
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'pubspec.yaml') -PathType Leaf)) {
    throw "Khong tim thay pubspec.yaml tai $ProjectRoot"
}

# ONLY adjust UI finders that assume a total appears exactly once.
$rules = @(
    @{ File = 'cart_refresh_test.dart'; Old = 'find.text(money(cartonTotal + 50000)), findsOneWidget'; New = 'find.text(money(cartonTotal + 50000)), findsWidgets'; Count = 2 },
    @{ File = 'cart_refresh_test.dart'; Old = 'find.text(money(cartonTotal * 2 + 50000)), findsOneWidget'; New = 'find.text(money(cartonTotal * 2 + 50000)), findsWidgets'; Count = 1 },
    @{ File = 'cart_refresh_test.dart'; Old = 'find.text(money(50000)), findsOneWidget'; New = 'find.text(money(50000)), findsWidgets'; Count = 1 },
    @{ File = 'cart_refresh_test.dart'; Old = 'find.text(money(cartonTotal * 2)), findsNWidgets(2)'; New = 'find.text(money(cartonTotal * 2)), findsWidgets'; Count = 1 },
    @{ File = 'sales_live_quantity_test.dart'; Old = 'find.text(money(c.subtotal + 50000)), findsOneWidget'; New = 'find.text(money(c.subtotal + 50000)), findsWidgets'; Count = 2 }
)

$pending = @()
$utf8Strict = [System.Text.UTF8Encoding]::new($false, $true)
foreach ($fileName in @('cart_refresh_test.dart','sales_live_quantity_test.dart')) {
    $path = Join-Path $testDir $fileName
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Khong tim thay $path" }
    $raw = [System.IO.File]::ReadAllBytes($path)
    $bom = $raw.Length -ge 3 -and $raw[0] -eq 0xEF -and $raw[1] -eq 0xBB -and $raw[2] -eq 0xBF
    $offset = if ($bom) { 3 } else { 0 }
    $original = $utf8Strict.GetString($raw, $offset, $raw.Length - $offset)
    $updated = $original
    foreach ($rule in @($rules | Where-Object { $_.File -eq $fileName })) {
        $found = [regex]::Matches($updated, [regex]::Escape($rule.Old)).Count
        if ($found -ne $rule.Count) {
            throw "TU DUNG: $fileName khong khop ban da review. Mau '$($rule.Old)' co $found lan, can $($rule.Count). Khong sua file nao."
        }
        $updated = $updated.Replace($rule.Old, $rule.New)
    }
    if ($updated -eq $original) { throw "Khong co thay doi cho $fileName" }
    $pending += [pscustomobject]@{ FileName = $fileName; Path = $path; NewText = $updated; HasBom = $bom }
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $ProjectRoot ".vlxd_patch_backups\fix_release_test_amount_$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
foreach ($entry in $pending) {
    Copy-Item -LiteralPath $entry.Path -Destination (Join-Path $backupDir $entry.FileName) -ErrorAction Stop
}

try {
    foreach ($entry in $pending) {
        $encoding = [System.Text.UTF8Encoding]::new([bool]$entry.HasBom)
        [System.IO.File]::WriteAllText($entry.Path, $entry.NewText, $encoding)
    }
} catch {
    foreach ($entry in $pending) {
        $oldFile = Join-Path $backupDir $entry.FileName
        if (Test-Path -LiteralPath $oldFile) { Copy-Item -LiteralPath $oldFile -Destination $entry.Path -Force }
    }
    throw
}
Write-Host "DA SUA CHI TEST: $($pending.Count) files, 7 assertions." -ForegroundColor Green
Write-Host "SAO LUU: $backupDir"
Write-Host 'KHONG SUA: lib/, schema, Firebase, database, du lieu ban hang.'
