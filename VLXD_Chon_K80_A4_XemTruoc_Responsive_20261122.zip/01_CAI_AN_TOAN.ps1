﻿$ErrorActionPreference = 'Stop'
$project = (Get-Location).Path
if (!(Test-Path (Join-Path $project 'pubspec.yaml'))) { throw 'Run in Flutter project root (D:\app\vlxd_app).' }
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Get-Content (Join-Path $patchRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$targets = @('lib/ui/invoices.dart', 'lib/ui/sales.dart')
$writePlans = @()
function Get-TextHash([string]$value) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [Text.Encoding]::UTF8.GetBytes($value)
    return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
  } finally { $sha.Dispose() }
}
foreach ($relative in $targets) {
  $relativeWin = $relative.Replace('/', '\')
  $currentPath = Join-Path $project $relativeWin
  $patchPath = Join-Path $patchRoot "files\$relativeWin"
  if (!(Test-Path $currentPath) -or !(Test-Path $patchPath)) { throw "Missing $relative" }
  $current = [IO.File]::ReadAllText($currentPath, [Text.Encoding]::UTF8)
  $normalized = $current.Replace("`r`n", "`n")
  $currentHash = Get-TextHash $normalized
  $valid = @($manifest.baseline_hashes.PSObject.Properties[$relative].Value)
  if ($valid -notcontains $currentHash) {
    throw "SOURCE CHANGED: $relative`nStop to prevent overwriting Codex changes. Share newest ZIP for a new patch."
  }
  $replacement = [IO.File]::ReadAllText($patchPath, [Text.Encoding]::UTF8)
  if ((Get-TextHash $replacement) -ne $manifest.patched_hashes.PSObject.Properties[$relative].Value) {
    throw "PATCH HASH FAIL: $relative"
  }
  if ($current.Contains("`r`n")) { $replacement = $replacement.Replace("`n", "`r`n") }
  $writePlans += [PSCustomObject]@{ Destination=$currentPath; Content=$replacement; Name=$relativeWin }
}
$testRel='test/invoice_paper_picker_test.dart'
$testDest = Join-Path $project $testRel.Replace('/', '\')
if (Test-Path $testDest) { throw "Test already exists: $testRel. Stop to avoid overwrite." }
$testSrc=Join-Path $patchRoot "files\$($testRel.Replace('/', '\'))"
$testText=[IO.File]::ReadAllText($testSrc, [Text.Encoding]::UTF8)
if ((Get-TextHash $testText) -ne $manifest.patched_hashes.PSObject.Properties[$testRel].Value) { throw 'PATCH TEST HASH FAIL' }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $project ".vlxd_patch_backups\invoice_picker_$stamp"
foreach ($p in $writePlans) {
  $dst = Join-Path $backup $p.Name
  New-Item -ItemType Directory -Force (Split-Path -Parent $dst) | Out-Null
  Copy-Item -LiteralPath $p.Destination -Destination $dst -ErrorAction Stop
}
# All preconditions checked and backup completed before writing.
try {
  foreach ($p in $writePlans) { [IO.File]::WriteAllText($p.Destination, $p.Content, [Text.UTF8Encoding]::new($false)) }
  [IO.File]::WriteAllText($testDest, $testText, [Text.UTF8Encoding]::new($false))
} catch {
  foreach ($p in $writePlans) {
    $old = Join-Path $backup $p.Name
    if (Test-Path $old) { Copy-Item -LiteralPath $old -Destination $p.Destination -Force }
  }
  if (Test-Path $testDest) { Remove-Item -LiteralPath $testDest -Force }
  throw
}
Write-Host "PATCH INSTALLED. Backups: $backup" -ForegroundColor Green
Write-Host 'Only invoice UI / print navigation updated. No database or Firebase changes.'
