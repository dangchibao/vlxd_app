﻿$ErrorActionPreference = 'Stop'
$project = (Get-Location).Path
if (!(Test-Path (Join-Path $project 'pubspec.yaml'))) { throw 'Not in Flutter project root.' }
Write-Host '1/2 - flutter analyze --no-pub'
flutter analyze --no-pub
if ($LASTEXITCODE -ne 0) { throw 'Analyze failed; stop without demo.' }
Write-Host '2/2 - invoice picker / print regression tests'
flutter test --no-pub test/invoice_paper_picker_test.dart test/print_layout_test.dart test/invoice_snapshot_test.dart
if ($LASTEXITCODE -ne 0) { throw 'Tests failed; stop without demo.' }
Write-Host 'ALL CHECKS PASSED. You can launch Windows demo.' -ForegroundColor Green
