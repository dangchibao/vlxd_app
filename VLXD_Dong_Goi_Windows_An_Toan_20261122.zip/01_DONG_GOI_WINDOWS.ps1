param(
    [string]$ProjectRoot = 'D:\app\vlxd_app',
    [switch]$SkipTests,
    [string]$ExistingIss = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

function Check-Exit([string]$Step) {
    if ($LASTEXITCODE -ne 0) { throw "$Step failed. Exit code: $LASTEXITCODE" }
}

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'pubspec.yaml') -PathType Leaf)) {
    throw "Not a Flutter project: $ProjectRoot"
}
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    $flutterBin = 'D:\development\flutter\bin'
    if (Test-Path (Join-Path $flutterBin 'flutter.bat')) { $env:Path = "$flutterBin;$env:Path" }
}
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw 'Flutter not found. Check D:\development\flutter\bin.'
}

$packageDir = Join-Path $ProjectRoot 'release\packages'
New-Item -ItemType Directory -Force -Path $packageDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'

Push-Location $ProjectRoot
try {
    Write-Host '[1/4] Static analysis ...' -ForegroundColor Cyan
    & flutter analyze --no-pub
    Check-Exit 'flutter analyze'

    if (-not $SkipTests) {
        Write-Host '[2/4] Flutter tests ...' -ForegroundColor Cyan
        & flutter test --no-pub
        Check-Exit 'flutter test'
    } else {
        Write-Warning 'Tests were skipped by the user; package is NOT test-verified.'
    }

    Write-Host '[3/4] Building Windows release ...' -ForegroundColor Cyan
    Write-Warning 'Build uses CURRENT project release defaults. Inspect pending offline queues before installing/using on real data.'
    # This only builds; it DOES NOT launch the application or sync any data.
    & flutter build windows --release --dart-define=DEMO_MODE=false
    Check-Exit 'flutter build windows'

    $releaseCandidates = @(
        (Join-Path $ProjectRoot 'build\windows\x64\runner\Release'),
        (Join-Path $ProjectRoot 'build\windows\runner\Release')
    )
    $releaseDir = $null
    foreach ($candidate in $releaseCandidates) {
        if ((Test-Path -LiteralPath (Join-Path $candidate 'vlxd_app.exe') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $candidate 'data') -PathType Container)) {
            $releaseDir = $candidate
            break
        }
    }
    if (-not $releaseDir) {
        throw 'Windows release with vlxd_app.exe and data/ not found. Do not package only the EXE.'
    }

    Write-Host '[4/4] Packaging entire Windows Release ...' -ForegroundColor Cyan
    $portableZip = Join-Path $packageDir "VLXD_App_Windows_Portable_$stamp.zip"
    Compress-Archive -Path (Join-Path $releaseDir '*') -DestinationPath $portableZip -CompressionLevel Optimal
    if (-not (Test-Path -LiteralPath $portableZip)) { throw 'Portable ZIP not created.' }

    $manifestPath = Join-Path $packageDir "BUILD_INFO_$stamp.txt"
    $exeHash = (Get-FileHash -LiteralPath (Join-Path $releaseDir 'vlxd_app.exe') -Algorithm SHA256).Hash
    @(
      "Built: $stamp",
      "Project: $ProjectRoot",
      "Release: $releaseDir",
      "Portable ZIP: $portableZip",
      "EXE SHA256: $exeHash",
      'NOTE: No install, no uninstall, no Firebase deploy and no data changes were performed.'
    ) | Out-File -LiteralPath $manifestPath -Encoding UTF8

    Write-Host ''
    Write-Host 'WINDOWS PORTABLE PACKAGE CREATED:' -ForegroundColor Green
    Write-Host $portableZip
    Write-Host "Build executable: $(Join-Path $releaseDir 'vlxd_app.exe')"

    # Do NOT invent an AppId for an installed Inno Setup app.
    # If the user supplies the previous .iss, compile it, assuming it still points to the current release.
    if ($ExistingIss -ne '') {
        if (-not (Test-Path -LiteralPath $ExistingIss -PathType Leaf)) {
            throw "Existing Inno Setup script not found: $ExistingIss"
        }
        $isccCandidates = @(
            'D:\Inno Setup 6\ISCC.exe',
            'C:\Program Files (x86)\Inno Setup 6\ISCC.exe',
            'C:\Program Files\Inno Setup 6\ISCC.exe'
        )
        $iscc = $isccCandidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
        if (-not $iscc) { throw 'Inno Setup ISCC.exe not found.' }
        Write-Warning 'Compiling your existing ISS. Verify its [Files] Source references the new Release directory and its AppId matches the installed VLXD app.'
        & $iscc $ExistingIss
        Check-Exit 'Inno Setup compile'
        Write-Host 'Inno Setup completed. Check OutputDir declared inside the .iss file.' -ForegroundColor Green
    } else {
        Write-Host ''
        Write-Warning 'No existing .iss provided: Setup installer NOT created, because changing Inno AppId can break upgrade compatibility.'
        Write-Host 'Use the portable ZIP now. To make an installer, locate the OLD .iss and rerun with -ExistingIss <path>.'
    }
} finally {
    Pop-Location
}
