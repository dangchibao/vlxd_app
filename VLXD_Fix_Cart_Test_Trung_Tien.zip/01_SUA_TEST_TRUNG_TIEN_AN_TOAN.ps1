param([string]$Project = 'D:\app\vlxd_app')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$target = Join-Path $Project 'test\cart_customer_test.dart'
if (-not (Test-Path -LiteralPath (Join-Path $Project 'pubspec.yaml'))) {
    throw "Khong thay du an Flutter tai: $Project"
}
if (-not (Test-Path -LiteralPath $target)) {
    throw "Khong thay file test: $target"
}

# Test truoc day doi chinh xac 1 Text, nhung UI nay hien tong tien o 2 vi tri.
# 'findsWidgets' van kiem tra co it nhat 1 Text dung gia tri, khong phu thuoc so noi hien thi.
$before = 'expect(find.text(money(subtotal + 50000 - discount)), findsOneWidget);'
$after  = 'expect(find.text(money(subtotal + 50000 - discount)), findsWidgets);'
$bytes = [System.IO.File]::ReadAllBytes($target)
$hadBom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
$utf8Strict = [System.Text.UTF8Encoding]::new($false, $true)
$content = $utf8Strict.GetString($bytes)
if ($content.StartsWith([string][char]0xFEFF)) { $content = $content.Substring(1) }

if ($content.Contains($after) -and -not $content.Contains($before)) {
    Write-Host 'File test da duoc sua truoc do. Khong can thay doi.' -ForegroundColor Yellow
    exit 0
}
$matches = [regex]::Matches($content, [regex]::Escape($before))
if ($matches.Count -ne 1) {
    throw "Khong tim thay dung 1 dong test can sua (tim thay $($matches.Count)). Dung de tranh ghi de thay doi moi."
}
$newContent = $content.Replace($before, $after)
$backupDir = Join-Path $Project ('.vlxd_patch_backups\fix_cart_test_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$backup = Join-Path $backupDir 'cart_customer_test.dart'
Copy-Item -LiteralPath $target -Destination $backup -ErrorAction Stop
try {
    [System.IO.File]::WriteAllText($target, $newContent, [System.Text.UTF8Encoding]::new($hadBom))
} catch {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    throw
}
Write-Host 'Da sua 1 assertion trong test\cart_customer_test.dart (findsOneWidget -> findsWidgets).' -ForegroundColor Green
Write-Host "Da sao luu: $backup"
Write-Host 'Khong thay doi sales.dart, logic thanh toan, SQLite hay Firebase.'
