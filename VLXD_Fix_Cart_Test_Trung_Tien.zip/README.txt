BAN VA: VLXD - Fix widget test bi trung gia tri 370.600 d

Nguyen nhan: Test cu o test/cart_customer_test.dart dong 70 dung findsOneWidget
nhung UI hien cung tong tien tai hai vi tri, test that bai vi co 2 widget.

Sua duy nhat 1 assertion thanh findsWidgets. Khong thay doi giao dien,
nghiep vu, database hay Firebase. Script tu kiem tra dong goc va sao luu file;
neu Codex da thay doi dong nay thi khong ghi de.

1. Copy ZIP vao D:\app\vlxd_app
2. Trong PowerShell:
   cd D:\app\vlxd_app
   Expand-Archive -LiteralPath '.\VLXD_Fix_Cart_Test_Trung_Tien.zip' -DestinationPath '.\.vlxd_fix_cart_test' -Force
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\.vlxd_fix_cart_test\01_SUA_TEST_TRUNG_TIEN_AN_TOAN.ps1'
3. Chay test rieng (nhanh):
   flutter test --no-pub test/cart_customer_test.dart
4. Neu dat, chay lai script kiem tra nhom 1:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\.vlxd_group1_patch\02_KIEM_TRA_VA_CHAY_DEMO.ps1'

Test full, demo van can duoc chay tren may cua ban; ZIP khong chua SDK/du lieu.
