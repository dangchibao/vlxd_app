param(
    [string]$ProjectRoot = "D:\app\vlxd_app"
)
$ErrorActionPreference = "Stop"
$patchRoot = Join-Path $PSScriptRoot "patch"
$domainPath = Join-Path $ProjectRoot "lib\domain\shop.dart"
$operationPath = Join-Path $ProjectRoot "lib\ui\operations.dart"
if (-not (Test-Path $domainPath) -or -not (Test-Path $operationPath)) {
    throw "Không tìm thấy dự án Flutter VLXD: $ProjectRoot"
}
$domainText = [IO.File]::ReadAllText($domainPath)
$operationsText = [IO.File]::ReadAllText($operationPath)
if (-not $domainText.Contains("archivedFromLists") -or -not $operationsText.Contains("_inventoryLotLabel")) {
    throw "Mã nguồn thiếu chức năng v2. DỪNG để tránh ghi đè bản khác. Hãy gửi ZIP mã nguồn mới nhất."
}
$backupRoot = "D:\VLXD_Backup\VLXD_Before_Upgrade_" + (Get-Date -Format "yyyyMMdd_HHmmss")
New-Item -ItemType Directory -Force $backupRoot | Out-Null
$all = Get-ChildItem -LiteralPath $patchRoot -File -Recurse
# Back up ALL originals before changing any file.
foreach ($entry in $all) {
    $relative = $entry.FullName.Substring($patchRoot.Length).TrimStart('\')
    $target = Join-Path $ProjectRoot $relative
    if (Test-Path -LiteralPath $target) {
        $backup = Join-Path $backupRoot $relative
        $folder = Split-Path $backup -Parent
        New-Item -ItemType Directory -Force $folder | Out-Null
        Copy-Item -LiteralPath $target -Destination $backup -Force
    }
}
foreach ($entry in $all) {
    $relative = $entry.FullName.Substring($patchRoot.Length).TrimStart('\')
    $target = Join-Path $ProjectRoot $relative
    $folder = Split-Path $target -Parent
    New-Item -ItemType Directory -Force $folder | Out-Null
    Copy-Item -LiteralPath $entry.FullName -Destination $target -Force
    Write-Host "Da cap nhat: $relative"
}
Write-Host "DA SAO LUU: $backupRoot" -ForegroundColor Green
Write-Host "Chua sua SQLite, Firebase hay ban EXE/Web. Chay flutter pub get, analyze va test." -ForegroundColor Yellow
