# VLXD Bảy Hải – Bản cập nhật an toàn (BETA – chưa xác nhận production)

## Những phần đã có trong mã nguồn

- **Đơn vị tính:** chặn mọi đổi đơn vị khi sản phẩm có lô hoặc lịch sử, không chỉ trường hợp `unit` rỗng.
- **Cảnh báo:** tồn <=0 là Hết hàng; nếu >0 và ngưỡng >0 và tồn <= ngưỡng mới là Sắp hết.
- **Mã lô:** lô mới được ghi `lotNumber` cố định; lô cũ có nút `Cố định mã lô` dành cho chủ cửa hàng. Mọi màn hình Kho, Kiểm kê, Chi tiết sản phẩm hiển thị `MÃ SP – Lô 001`. UUID gốc giữ nguyên.
- **Trùng tên:** so khớp tên không phân biệt một số khác biệt dấu tiếng Việt/ký tự, gợi ý tên gần giống khi đang nhập; kiểm tra mã sản phẩm cũ.
- **Lịch:** Flutter localizations tiếng Việt + khai báo `flutter_localizations` trong pubspec.
- **In KV804 80mm:** thêm lựa chọn In 80 mm ở Chi tiết đơn đã bán. PDF in đen trắng, chọn máy in KV804 trong hộp thoại hệ thống. Không điều khiển USB trực tiếp; cần máy in đã cài driver và giấy 80 mm.
- **Đổi trả:** có nút Trả TOÀN BỘ đơn đã bán cho chủ cửa hàng. Chặn trả lần hai, khôi phục đúng lô cũ, lưu lịch sử, trừ công nợ tương ứng, chỉ ghi hoàn tiền khi chủ xác nhận đã hoàn NGOÀI ứng dụng. Chưa hỗ trợ trả một phần, chuyển tiền tự động, trả đơn đang có giao hàng.
- **Báo cáo:** xuất hàng trả là số dương nhập lại, dòng tiền hoàn là số âm trong danh sách thu/chi.
- **Sao lưu:** `tools/vlxd_backup_safe` sao lưu Firestore (9 collection store + meta), kiểm SHA-256, khôi phục chỉ vào store STAGING hoàn toàn trống. Không hỗ trợ ghi đè production tự động để tránh mất dữ liệu. Không sao lưu Firebase Auth.
- **Nhà cung cấp/Đơn nhập:** có `lib/domain/procurement_draft.dart` mô hình kiểm tra đơn mua làm nền tảng. CHƯA tích hợp giao diện, Firestore Security Rules, nhập kho hay công nợ nhà cung cấp production. Không dùng module nháp này làm sổ tiền thật.

## Cách cài bản vá

1. ĐÓNG phần mềm Windows; không thao tác nghiệp vụ khi thay bản.
2. Giải nén ZIP tới `D:\VLXD_Backup\VLXD_Upgrade_Beta` (KHÔNG giải nén đè trực tiếp vào thư mục ứng dụng).
3. Trong PowerShell, chạy:

```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "D:\VLXD_Backup\VLXD_Upgrade_Beta\install-safe.ps1" -ProjectRoot "D:\app\vlxd_app"
```

Script sẽ tạo backup có timestamp trong `D:\VLXD_Backup`, rồi mới chép đè các file Dart. Nó CHẶN cài nếu thiếu nền tảng bản v2 (quản lý sản phẩm an toàn) để tránh mất chức năng. Không sửa SQLite/Firebase.

4. Kiểm tra bắt buộc (bởi vì đây là bản sửa nghiệp vụ tiền và kho):

```
cd D:\app\vlxd_app
flutter pub get
dart format lib/domain/shop.dart lib/domain/invoice_filter.dart lib/domain/procurement_draft.dart lib/ui/app.dart lib/ui/catalog.dart lib/ui/operations.dart lib/ui/invoices.dart lib/ui/sales.dart lib/ui/accounting.dart lib/ui/debt.dart lib/ui/print_service.dart
flutter analyze --no-fatal-infos
flutter test
```

5. Chỉ dùng thử các tính năng tài chính trên dữ liệu DEMO trước. KHÔNG thực hiện trả hàng thật cho đến khi Firestore Rules và các test 2 client được kiểm chứng.

## Sao lưu Firestore thật (không xóa)

Yêu cầu: Node.js, Google Application Default Credentials có quyền đọc Firestore, project chính xác, không chia sẻ token. `firebase login` không thay thế ADC.

```
cd D:\app\vlxd_app\tools\vlxd_backup_safe
npm install
gcloud auth application-default login
node vlxd-backup.cjs backup --project vlxd-bay-hai --store bay-hai --out "D:\VLXD_Backup\vlxd_prod_snapshot_20261115.json"
node vlxd-backup.cjs verify --file "D:\VLXD_Backup\vlxd_prod_snapshot_20261115.json"
node vlxd-backup.cjs plan --file "D:\VLXD_Backup\vlxd_prod_snapshot_20261115.json"
```

Tên file backup phải mới; script không ghi đè backup cũ. JSON chứa thông tin khách hàng/hóa đơn: không push GitHub.

Khôi phục STAGING (không ghi vào bay-hai):

```
node vlxd-backup.cjs restore-staging --project vlxd-bay-hai --file "D:\VLXD_Backup\vlxd_prod_snapshot_20261115.json" --target-store bay-hai-restore-check --apply
```

KHÔNG có nút/command tự động restore production. Quy trình restore production đầy đủ cần đóng băng ghi, xác minh hàng đợi offline trên MỌI thiết bị, kiểm tra Auth/Rules, đối chiếu tài chính và kế hoạch rollback; thiếu các điều kiện này có nguy cơ mất số liệu thật.

## Cảnh báo

- ZIP này xây trên bản mã nguồn `VLXD_Kho_Source.zip` + các bản vá kho v2 và form tiếng Việt gần đây. Nếu máy bạn có code khác sau đó, bản sao lưu ở bước cài giữ lại bản cũ; phải đối chiếu Git diff để tránh mất thay đổi.
- Chưa có Flutter SDK trong môi trường đóng gói nên CHƯA xác nhận `flutter analyze/test` PASS. Không phát hành cho khách trước khi chạy kiểm thử và đối chiếu số dư.
- Xem `CHANGES_FOR_REVIEW.patch` và `SHA256_MANIFEST.txt` để kiểm tra chính xác các file sửa.
