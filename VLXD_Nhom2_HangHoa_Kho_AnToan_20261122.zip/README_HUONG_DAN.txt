VLXD APP - NHOM 2: HANG HOA & KHO (22/11/2026)

Can cu: source ZIP VLXD_Source_Review_20261122_184340.zip.
Nhanh Nhom 1 da dat test tren may nguoi dung; goi nay KHONG sua sales.dart.

THAY DOI
- Hang hoa: bo loc nhom va quy cach nam trong 'Bo loc nang cao'; trang thai van hien ngay.
  So san pham duoc hien; neu dang loc an van thay nhan bo loc.
- Danh sach gon Hang hoa: ten 1 dong, gia/ton 2 dong; phan mo rong van co gia von lo, ghi chu, chuc nang quan ly.
- Kho: danh sach gon theo tung san pham; SKU, kha dung, canh bao ton; hai nut Nhap hang va Kiem ke hien ngay.
  Bam mo rong de xem ton/giu, tung lo, an lo rong, thao tac quan tri neu du quyen.
- Danh sach gon hien toi da 20 dong/trang (thay vi 10), khong thay doi du lieu.
- Test moi cho bo loc, nut kho va kiem tra UI khong sua du lieu.

KHONG THAY DOI
- Domain, Firebase, SQLite, schema, gia, ton, nhap kho, kiem ke, quyen, sync, sales.dart, file config.
- Khong overwrite file Codex sua khac ban source cu: installer se TU DUNG.

CACH DUNG (sao chep ZIP vao D:\app\vlxd_app)
1) Giai nen vao .vlxd_group2_patch
2) powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\.vlxd_group2_patch\01_CAI_AN_TOAN.ps1"
3) powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\.vlxd_group2_patch\02_KIEM_TRA_VA_CHAY_DEMO.ps1"

LUU Y
- Script cai sao luu 2 file cu vao .vlxd_patch_backups\group2_<timestamp>.
- 02 chi chay DEMO khi analyze va test dat; no khong deploy app that hay update EXE da cai.
- Chua chay Flutter analyze/test trong moi truong tao patch do khong co Flutter SDK.
- Nen dong Codex va ung dung truoc khi cai, tranh source thay doi dong thoi.
