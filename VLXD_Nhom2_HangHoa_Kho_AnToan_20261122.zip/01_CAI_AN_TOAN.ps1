$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $PSScriptRoot 'manifest.json'
if (-not (Test-Path (Join-Path $root 'pubspec.yaml'))) {
  throw 'Khong thay pubspec.yaml. Hay giai nen ZIP trong thu muc goc vlxd_app.'
}
$m = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$items = @($m.sources)
$toWrite = @()
foreach ($item in $items) {
  $dst = Join-Path $root $item.path
  $src = Join-Path (Join-Path $PSScriptRoot 'files') $item.path
  if (-not (Test-Path -LiteralPath $dst)) { throw "Thieu file goc: $($item.path)" }
  if (-not (Test-Path -LiteralPath $src)) { throw "Thieu file patch: $($item.path)" }
  $patchHash = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
  if ($patchHash -ne $item.new) { throw "Patch bi sai checksum: $($item.path)" }
  $current = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
  if ($current -eq $item.new) { continue }
  if ($current -ne $item.old) {
    throw "TU DUNG: $($item.path) da khac ban source gui truoc. Khong ghi de sua doi moi cua Codex."
  }
  $toWrite += $item
}
$test = $m.new_test
$testDst = Join-Path $root $test.path
$testSrc = Join-Path (Join-Path $PSScriptRoot 'files') $test.path
if ((Get-FileHash -LiteralPath $testSrc -Algorithm SHA256).Hash -ne $test.new) {
  throw 'File test trong ZIP sai checksum.'
}
$writeTest = $true
if (Test-Path -LiteralPath $testDst) {
  if ((Get-FileHash -LiteralPath $testDst -Algorithm SHA256).Hash -ne $test.new) {
    throw 'TU DUNG: test/group2_compact_ui_test.dart da ton tai voi noi dung khac.'
  }
  $writeTest = $false
}
if ($toWrite.Count -eq 0 -and -not $writeTest) {
  Write-Host 'Patch Nhom 2 da duoc cai, khong thay doi gi.' -ForegroundColor Green
  exit 0
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $root ".vlxd_patch_backups\group2_$stamp"
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($item in $toWrite) {
  $dst = Join-Path $root $item.path
  $bak = Join-Path $backup $item.path
  New-Item -ItemType Directory -Path (Split-Path -Parent $bak) -Force | Out-Null
  Copy-Item -LiteralPath $dst -Destination $bak -ErrorAction Stop
}
$written = @()
try {
  foreach ($item in $toWrite) {
    $src = Join-Path (Join-Path $PSScriptRoot 'files') $item.path
    $dst = Join-Path $root $item.path
    Copy-Item -LiteralPath $src -Destination $dst -Force -ErrorAction Stop
    $written += $item
    if ((Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -ne $item.new) {
      throw "Checksum sau khi cai sai: $($item.path)"
    }
  }
  if ($writeTest) {
    New-Item -ItemType Directory -Path (Split-Path -Parent $testDst) -Force | Out-Null
    Copy-Item -LiteralPath $testSrc -Destination $testDst -ErrorAction Stop
    if ((Get-FileHash -LiteralPath $testDst -Algorithm SHA256).Hash -ne $test.new) {
      throw 'Checksum test moi sai.'
    }
  }
} catch {
  foreach ($item in $written) {
    $bak = Join-Path $backup $item.path
    Copy-Item -LiteralPath $bak -Destination (Join-Path $root $item.path) -Force
  }
  if ($writeTest -and (Test-Path -LiteralPath $testDst)) {
    Remove-Item -LiteralPath $testDst -Force
  }
  throw
}
Write-Host 'DA CAI NANG CAP NHOM 2 - HANG HOA VA KHO.' -ForegroundColor Green
Write-Host "Ban sao luu file cu: $backup"
Write-Host 'Khong thay doi du lieu ban hang, SQLite, Firebase, schema.'
