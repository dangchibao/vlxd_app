$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $root 'pubspec.yaml'))) { throw 'Sai thu muc Flutter.' }
Set-Location -LiteralPath $root
$flutterCmd = Get-Command flutter -ErrorAction SilentlyContinue
if ($null -ne $flutterCmd) {
  $flutter = $flutterCmd.Source
} elseif (Test-Path 'D:\development\flutter\bin\flutter.bat') {
  $flutter = 'D:\development\flutter\bin\flutter.bat'
} else {
  throw 'Khong tim thay Flutter. Kiem tra Flutter SDK.'
}
Write-Host '1/3 - flutter analyze'
& $flutter analyze --no-pub
if ($LASTEXITCODE -ne 0) { throw 'Analyze chua dat, chua chay demo.' }
Write-Host '2/3 - Test Nhom 2 va cac trang UI lien quan'
& $flutter test --no-pub test/group2_compact_ui_test.dart test/sales_ux_test.dart test/display_preferences_test.dart
if ($LASTEXITCODE -ne 0) { throw 'Test chua dat, chua chay demo.' }
Write-Host '3/3 - Run Windows DEMO (khong Firebase production)'
& $flutter run -d windows --no-pub --dart-define=DEMO_MODE=true
if ($LASTEXITCODE -ne 0) { throw 'Windows demo chua chay duoc.' }
