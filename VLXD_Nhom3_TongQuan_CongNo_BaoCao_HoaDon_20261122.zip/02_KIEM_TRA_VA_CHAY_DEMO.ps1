﻿$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
Push-Location $project
try {
    $flutter = 'flutter'
    if (!(Get-Command flutter -ErrorAction SilentlyContinue)) {
        $flutter = 'D:\development\flutter\bin\flutter.bat'
    }
    if (!(Get-Command $flutter -ErrorAction SilentlyContinue) -and !(Test-Path -LiteralPath $flutter)) {
        throw 'Chua tim thay Flutter SDK. Kiem tra D:\development\flutter\bin\flutter.bat'
    }
    Write-Host '1/3 - Flutter analyze (khong update dependency)' -ForegroundColor Cyan
    & $flutter analyze --no-pub
    if ($LASTEXITCODE -ne 0) { throw 'Analyze loi. Dung, khong chay demo.' }
    Write-Host '2/3 - Regression test cua Nhóm 3 + hoa don/cong no' -ForegroundColor Cyan
    & $flutter test --no-pub test/group3_ui_reports_test.dart test/invoices_test.dart test/debt_view_test.dart test/sales_ux_test.dart
    if ($LASTEXITCODE -ne 0) { throw 'Test loi. Dung, khong chay demo.' }
    Write-Host '3/3 - Mo Windows DEMO (khong ket noi production)' -ForegroundColor Green
    & $flutter run -d windows --no-pub --dart-define=DEMO_MODE=true
    if ($LASTEXITCODE -ne 0) { throw 'Khong mo duoc Windows demo.' }
} finally {
    Pop-Location
}
