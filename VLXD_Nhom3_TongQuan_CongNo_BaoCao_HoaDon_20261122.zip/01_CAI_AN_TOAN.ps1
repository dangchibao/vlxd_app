﻿$ErrorActionPreference = 'Stop'
$packageRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$project = (Resolve-Path -LiteralPath (Join-Path $packageRoot '..')).Path
$manifest = Get-Content -LiteralPath (Join-Path $packageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json

function Sha([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToUpperInvariant() }
function SourcePath([string]$rel) { return Join-Path $project ($rel -replace '/', [IO.Path]::DirectorySeparatorChar) }
function PackagePath([string]$rel) { return Join-Path $packageRoot ($rel -replace '/', [IO.Path]::DirectorySeparatorChar) }

if (!(Test-Path -LiteralPath (Join-Path $project 'pubspec.yaml'))) {
    throw "Khong tim thay pubspec.yaml: $project"
}
$changes = New-Object System.Collections.ArrayList
foreach ($entry in $manifest.changes) {
    $dest = SourcePath $entry.path
    $src = PackagePath $entry.package_path
    if (!(Test-Path -LiteralPath $dest)) { throw "Thieu source: $dest" }
    if (!(Test-Path -LiteralPath $src)) { throw "Thieu patch: $src" }
    if ((Sha $dest) -ne $entry.original_sha256) {
        throw "FILE DA THAY DOI: $($entry.path) - DUNG, KHONG GHI DE. Gui ket qua cho ChatGPT."
    }
    if ((Sha $src) -ne $entry.new_sha256) { throw "Patch khong khop SHA: $src" }
    [void]$changes.Add([pscustomobject]@{Rel=$entry.path;Dest=$dest;Src=$src;New=$entry.new_sha256;IsNew=$false})
}
# operations.dart has two protected baselines: BEFORE and AFTER Group 2.
$opsDest = SourcePath 'lib/ui/operations.dart'
if (!(Test-Path -LiteralPath $opsDest)) { throw 'Thieu operations.dart' }
$opsHash = Sha $opsDest
$opsMatch = $manifest.operations_variants | Where-Object { $_.original_sha256 -eq $opsHash } | Select-Object -First 1
if ($null -eq $opsMatch) { throw 'operations.dart khong khop ban goc hoac Group 2. DUNG tranh de mat code Codex.' }
$opsSrc = PackagePath $opsMatch.package_path
if ((Sha $opsSrc) -ne $opsMatch.new_sha256) { throw 'Operations patch SHA loi' }
[void]$changes.Add([pscustomobject]@{Rel='lib/ui/operations.dart';Dest=$opsDest;Src=$opsSrc;New=$opsMatch.new_sha256;IsNew=$false})
foreach ($entry in $manifest.new_files) {
    $dest = SourcePath $entry.path
    $src = PackagePath $entry.package_path
    if (!(Test-Path -LiteralPath $src) -or (Sha $src) -ne $entry.new_sha256) { throw "Patch SHA loi: $src" }
    if (Test-Path -LiteralPath $dest) { throw "Da ton tai $dest - DUNG tranh ghi de test khac." }
    [void]$changes.Add([pscustomobject]@{Rel=$entry.path;Dest=$dest;Src=$src;New=$entry.new_sha256;IsNew=$true})
}
Write-Host "Da kiem tra $($changes.Count) file, operations baseline: $($opsMatch.name)" -ForegroundColor Cyan
# All checks must pass before making any change to code.
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupRoot = Join-Path $project ".vlxd_patch_backups\group3_$stamp"
foreach ($entry in $changes | Where-Object { -not $_.IsNew }) {
    $backup = Join-Path $backupRoot ($entry.Rel -replace '/', [IO.Path]::DirectorySeparatorChar)
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backup) | Out-Null
    Copy-Item -LiteralPath $entry.Dest -Destination $backup -ErrorAction Stop
}
$applied = New-Object System.Collections.ArrayList
try {
    foreach ($entry in $changes) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $entry.Dest) | Out-Null
        [void]$applied.Add($entry) # rollback even if copy fails halfway
        Copy-Item -LiteralPath $entry.Src -Destination $entry.Dest -Force -ErrorAction Stop
        if ((Sha $entry.Dest) -ne $entry.New) { throw "Sau khi cai SHA khong khop: $($entry.Rel)" }
    }
} catch {
    Write-Warning 'Cai ban va that bai, khoi phuc file goc...'
    foreach ($entry in $applied) {
        if ($entry.IsNew) { Remove-Item -LiteralPath $entry.Dest -Force -ErrorAction SilentlyContinue }
        else {
            $backup = Join-Path $backupRoot ($entry.Rel -replace '/', [IO.Path]::DirectorySeparatorChar)
            Copy-Item -LiteralPath $backup -Destination $entry.Dest -Force -ErrorAction SilentlyContinue
        }
    }
    throw
}
Write-Host "CAI NHOM 3 THANH CONG. Backup: $backupRoot" -ForegroundColor Green
Write-Host 'Khong thay doi database, Firebase, schema, config hay du lieu.'
Write-Host 'Chay 02_KIEM_TRA_VA_CHAY_DEMO.ps1 de test.'
