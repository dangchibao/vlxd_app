VLXD APP - NHOM 3 UI/UX - 22/11/2026
====================================
Source goc: VLXD_Source_Review_20261122_184340.zip

PHAM VI:
- Tong quan: Thu gon the viec dang mo, chia hai cot khi desktop rong.
- Cong no: Tab Khach hang va Luong doc lap, khong hien ca hai cung luc.
- Bao cao: Top san pham ban chay theo GIA TRI TIEN HANG (bao/cai/m2...); giu bang theo m2 trong muc mo rong.
- Hoa don: Tim kiem luon hien; bo loc nang cao mo khi can.
- KHONG sua logic giao dich, ton kho, cong no, PDF hoac Firebase.

CACH CAI:
1. Dong app va Codex dang sua; dat ZIP trong D:\app\vlxd_app.
2. Mo PowerShell tai D:\app\vlxd_app:
   Expand-Archive -LiteralPath '.\VLXD_Nhom3_TongQuan_CongNo_BaoCao_HoaDon_20261122.zip' -DestinationPath '.\.vlxd_group3_patch' -Force
3. Cai:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\.vlxd_group3_patch\01_CAI_AN_TOAN.ps1'
4. Test/demo:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\.vlxd_group3_patch\02_KIEM_TRA_VA_CHAY_DEMO.ps1'

AN TOAN:
- Script kiem tra SHA256 TAT CA file truoc khi ghi.
- operations.dart tu chon dung baseline truoc/sau Nhom 2.
- Neu file khac source du kien: TU DUNG; KHONG dung -Force hay ghi de thu cong.
- Sao luu ban goc tai .vlxd_patch_backups\group3_<timestamp>.
- File moi test/group3_ui_reports_test.dart se khong ghi de file da ton tai.
- CHUA CHAY Flutter analyze/test tren moi truong tao ZIP; can chay tren may Windows cua ban.
- DA KIEM TRA checksum va ZIP. Chua deploy, chua in thuc te, chua push Git.
