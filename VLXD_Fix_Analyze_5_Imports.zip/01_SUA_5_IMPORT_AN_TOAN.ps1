param([string]$Project = 'D:\app\vlxd_app')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$target = Join-Path $Project 'test\sales_ux_test.dart'
if (-not (Test-Path -LiteralPath (Join-Path $Project 'pubspec.yaml'))) {
    throw "Khong tim thay pubspec.yaml trong $Project"
}
if (-not (Test-Path -LiteralPath $target)) {
    throw "Khong tim thay test: $target"
}

$unused = @(
    "import 'package:vlxd_app/data/local/app_database.dart';",
    "import 'package:vlxd_app/data/local/cart_draft_repository.dart';",
    "import 'package:vlxd_app/data/sync/outbox_repository.dart';",
    "import 'package:drift/native.dart';",
    "import 'cart_draft_controller_test.dart' show main;"
)
$bytes = [System.IO.File]::ReadAllBytes($target)
$utf8 = [System.Text.UTF8Encoding]::new($false, $true)
$hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
$content = $utf8.GetString($bytes)
if ($hasBom -and $content.StartsWith([string][char]0xFEFF)) {
    $content = $content.Substring(1)
}
$newContent = $content
$removed = @()
foreach ($line in $unused) {
    $pattern = '(?m)^' + [regex]::Escape($line) + '[ \t]*(?:\r?\n|$)'
    if ([regex]::IsMatch($newContent, $pattern)) {
        $newContent = [regex]::Replace($newContent, $pattern, '')
        $removed += $line
    }
}

if ($removed.Count -eq 0) {
    Write-Host 'Khong co import thua. File co the da duoc sua.' -ForegroundColor Yellow
    exit 0
}

$backupDir = Join-Path $Project ('.vlxd_patch_backups\fix_analyze_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
Copy-Item -LiteralPath $target -Destination (Join-Path $backupDir 'sales_ux_test.dart') -ErrorAction Stop
try {
    [System.IO.File]::WriteAllText($target, $newContent, ([System.Text.UTF8Encoding]::new($hasBom)))
} catch {
    Copy-Item -LiteralPath (Join-Path $backupDir 'sales_ux_test.dart') -Destination $target -Force
    throw
}
Write-Host "Da xoa $($removed.Count) import khong su dung trong test\sales_ux_test.dart" -ForegroundColor Green
Write-Host "Da sao luu file cu: $backupDir"
Write-Host 'Khong sua logic ban hang, Firebase, SQLite, hay data.'
Write-Host 'Bay gio chay lai script 02_KIEM_TRA_VA_CHAY_DEMO.ps1 cua ban va.'
