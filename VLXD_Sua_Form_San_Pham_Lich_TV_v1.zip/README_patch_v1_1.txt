BẢN VÁ: Sửa khoảng cách form sản phẩm + lịch tiếng Việt

Đã sửa:
1) Form Chi tiết sản phẩm:
- Tăng khoảng cách giữa các ô nhập để không bị dồn, đè chữ.
- Gợi ý về mã sản phẩm nằm ngay dưới ô Mã sản phẩm / mã vạch.
- Sau đó mới tới ô Tên sản phẩm, rồi Kích thước.
- Đổi nhãn thành "Cảnh báo khi tồn kho còn (tùy chọn)".
- Ô "Lưu ý" cũng tăng khoảng cách và hiển thị dễ đọc hơn.

2) Lịch / DatePicker:
- Ép giao diện dùng locale tiếng Việt (vi_VN).
- Calendar trong showDatePicker sẽ hiển thị tiếng Việt sau khi rebuild app.

FILE ĐƯỢC CHỈNH:
- lib/ui/app.dart
- lib/ui/catalog.dart

CÁCH CHÉP ĐÈ:
1. Giải nén file ZIP này.
2. Chép đè thư mục lib vào dự án D:\app\vlxd_app.
3. Chạy:
   flutter clean
   flutter pub get
   flutter run -d windows

Nếu muốn cập nhật web:
   flutter build web
   firebase deploy --only hosting --project vlxd-bay-hai
