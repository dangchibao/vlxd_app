﻿$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$dest = Join-Path $project 'test\group3_ui_reports_test.dart'
$patch = Join-Path $PSScriptRoot 'files\test\group3_ui_reports_test.dart'
$expectedBefore = 'C8AA207E3E043FA2343D110DF0D6A3411D4F74CCA68859C5C20554D3C84D4720'
$expectedAfter = '4A5AF5672088106C652987E2298614DE20C8B52D31CC4FE0B4673251E8646AF0'

if (-not (Test-Path -LiteralPath (Join-Path $project 'pubspec.yaml'))) {
    throw 'Khong tim thay du an Flutter tai thu muc cha.'
}
if (-not (Test-Path -LiteralPath $dest)) { throw 'Khong tim thay file test can sua.' }
if (-not (Test-Path -LiteralPath $patch)) { throw 'Khong tim thay file ban va.' }
function FileHash([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant()
}
if ((FileHash $patch) -ne $expectedAfter) { throw 'Checksum ZIP khong khop. Khong cai.' }
$current = FileHash $dest
if ($current -eq $expectedAfter) {
    Write-Host 'Ban sua da duoc cai tu truoc. Khong thay doi gi.' -ForegroundColor Green
    exit 0
}
if ($current -ne $expectedBefore) {
    throw 'File test da thay doi khac ban goc. TU DUNG de tranh ghi de code moi.'
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $project ".vlxd_patch_backups\group3_invoice_filter_test_$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
$backup = Join-Path $backupDir 'group3_ui_reports_test.dart'
Copy-Item -LiteralPath $dest -Destination $backup -ErrorAction Stop
try {
    Copy-Item -LiteralPath $patch -Destination $dest -Force -ErrorAction Stop
    if ((FileHash $dest) -ne $expectedAfter) { throw 'Checksum sau khi cai khong khop.' }
} catch {
    Copy-Item -LiteralPath $backup -Destination $dest -Force -ErrorAction SilentlyContinue
    throw
}
Write-Host 'DA SUA TEST LOC HOA DON. Khong sua source/nghiep vu/du lieu.' -ForegroundColor Green
Write-Host "Ban sao luu: $backup"
