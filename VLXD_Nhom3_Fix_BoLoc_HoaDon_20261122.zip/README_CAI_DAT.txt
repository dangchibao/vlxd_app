VLXD NHOM 3 - FIX TEST BO LOC HOA DON
===================================
Pham vi: chi file test/group3_ui_reports_test.dart.
Sua 2 assertion tim text "Ngay ban" thanh kiem tra widget filter co key period-Toan bo.
Ly do: bang hoa don tren desktop luon co cot "Ngay ban" ngay ca khi bo loc dang dong.
Khong sua code ung dung, schema, Firebase, SQLite, don hang, cong no.

CAI DAT (PowerShell, sau khi giai nen vao D:\app\vlxd_app\.vlxd_fix_group3_filter):
cd D:\app\vlxd_app
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\.vlxd_fix_group3_filter\01_CAI_AN_TOAN.ps1"

KIEM TRA:
flutter test --no-pub test/group3_ui_reports_test.dart
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\.vlxd_group3_patch\02_KIEM_TRA_VA_CHAY_DEMO.ps1"

Scripts kiem tra SHA256 va sao luu file cu. Neu file da thay doi, script tu dung.
