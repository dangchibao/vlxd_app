﻿$ErrorActionPreference = 'Stop'
$project = (Get-Location).Path
if (!(Test-Path -LiteralPath (Join-Path $project 'pubspec.yaml'))) {
  throw 'Hay chay lenh trong D:\app\vlxd_app (Flutter project root).'
}
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$src = Join-Path $root 'files\lib\ui\invoices.dart'
$dest = Join-Path $project 'lib\ui\invoices.dart'
if (!(Test-Path -LiteralPath $dest)) { throw 'Thieu lib\ui\invoices.dart' }
if (!(Test-Path -LiteralPath $src)) { throw 'Thieu file patch.' }
function Hash([string]$p) { return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
$nowHash = Hash $dest
if ($nowHash -eq $manifest.patched_sha256) {
  Write-Host 'Da cai ban nang do net. Khong can cai lai.' -ForegroundColor Green
  exit 0
}
if ($nowHash -ne $manifest.baseline_sha256) {
  throw 'SOURCE KHAC PHIEN BAN: invoices.dart da duoc sua tiep. DUNG de tranh ghi de. Gui file invoices.dart moi nhat de tao ban va phu hop.'
}
if ((Hash $src) -ne $manifest.patched_sha256) { throw 'Patch checksum khong hop le.' }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $project ".vlxd_patch_backups\invoice_dpi_$stamp"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$backupFile = Join-Path $backupDir 'invoices.dart'
Copy-Item -LiteralPath $dest -Destination $backupFile -ErrorAction Stop
try {
  Copy-Item -LiteralPath $src -Destination $dest -Force -ErrorAction Stop
  if ((Hash $dest) -ne $manifest.patched_sha256) { throw 'Verify failed' }
} catch {
  Copy-Item -LiteralPath $backupFile -Destination $dest -Force
  throw
}
Write-Host 'DA CAI PATCH: preview K80 380 px / 216 DPI; A4 640 px / 160 DPI.' -ForegroundColor Green
Write-Host "Backup: $backupFile"
Write-Host 'Khong doi noi dung PDF, du lieu giao dich hay thong so may in.'
