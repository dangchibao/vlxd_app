﻿$ErrorActionPreference = 'Stop'
if (!(Test-Path 'pubspec.yaml')) { throw 'Hay chay trong thu muc goc vlxd_app.' }
Write-Host '1/2 - flutter analyze --no-pub'
flutter analyze --no-pub
if ($LASTEXITCODE -ne 0) { throw 'Analyze failed. Khong chay demo.' }
Write-Host '2/2 - invoice preview & print tests'
flutter test --no-pub test/invoice_paper_picker_test.dart test/print_layout_test.dart test/invoice_snapshot_test.dart
if ($LASTEXITCODE -ne 0) { throw 'Tests failed. Khong chay demo.' }
Write-Host 'ALL CHECKS PASSED. Mo demo bang: flutter run -d windows --no-pub --dart-define=DEMO_MODE=true' -ForegroundColor Green
