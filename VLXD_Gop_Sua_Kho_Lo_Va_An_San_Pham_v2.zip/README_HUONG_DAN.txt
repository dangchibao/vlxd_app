VLXD Bảy Hải – Gộp bản vá Kho + Quản lý sản phẩm v2

GỒM 4 FILE (chép đè lib đúng vị trí):
- lib/domain/shop.dart
- lib/controllers/shop_controller.dart (giữ từ bản quản lý sản phẩm an toàn v1)
- lib/ui/catalog.dart
- lib/ui/operations.dart

CÁC THAY ĐỔI
1) Kho: mã LO-UUID hiển thị thành Lô 001, Lô 002... theo vị trí trong danh sách lô gốc. UUID không đổi. Các số là nhãn hiển thị, không phải ID dùng trong chứng từ.
2) Có X đỏ cạnh mỗi lô. Chỉ chủ cửa hàng được ẩn lô với tồn=0 và giữ=0; giữ dữ liệu lô/lịch sử. Lô còn tồn bị chặn.
3) Sản phẩm đã ngừng kinh doanh và tồn=0, giữ=0 (kể cả có lô và lịch sử): Chủ cửa hàng có thể chọn Ẩn khỏi danh sách; không xóa dữ liệu.
4) Sản phẩm bị ẩn không xuất hiện trong Kho, danh sách Hàng hóa đang/ngừng kinh doanh. Chủ cửa hàng có mục Sản phẩm đã ẩn để phục hồi.
5) Chống trùng tên/mã và khôi phục kinh doanh vẫn giữ; mã SP0001... tự gợi ý.
6) Cảnh báo khi tồn kho còn: giữ nhãn dễ hiểu.

CÀI ĐẶT (SAO LƯU BÊN NGOÀI DỰ ÁN)
cd D:\app\vlxd_app
$stamp=Get-Date -Format yyyyMMdd_HHmmss
$backup="D:\VLXD_Backup\inventory_merge_$stamp"
New-Item -ItemType Directory -Force "$backup\lib\domain","$backup\lib\controllers","$backup\lib\ui" | Out-Null
Copy-Item .\lib\domain\shop.dart "$backup\lib\domain\shop.dart"
Copy-Item .\lib\controllers\shop_controller.dart "$backup\lib\controllers\shop_controller.dart"
Copy-Item .\lib\ui\catalog.dart "$backup\lib\ui\catalog.dart"
Copy-Item .\lib\ui\operations.dart "$backup\lib\ui\operations.dart"
Expand-Archive -Path .\VLXD_Gop_Sua_Kho_Lo_Va_An_San_Pham_v2.zip -DestinationPath . -Force
dart format .\lib\domain\shop.dart .\lib\controllers\shop_controller.dart .\lib\ui\catalog.dart .\lib\ui\operations.dart
flutter analyze --no-fatal-infos
flutter test

Không tự xóa Firebase/SQLite. Đóng ứng dụng trước khi giải nén.
CHÚ Ý: Chưa chạy flutter test trong môi trường tạo ZIP này. Cần chạy trên Windows và kiểm tra Rules, đồng bộ đa thiết bị trước khi triển khai production.
