VLXD APP - NHOM 1 BAN HANG - BAN VA CODE AN TOAN (2026-11-22)
==========================================================
Nguon doi chieu: VLXD_Source_Review_20261122_184340.zip
Chi thay doi:
  lib/ui/sales.dart
  test/sales_group1_ui_test.dart (file test moi)
Khong doi Firebase/SQLite, schema, controller, domain, cong no, ton kho.

DA CO SAN TRONG SOURCE CODEX: 3 che do thanh toan, 100k/500k/1m, menu Sửa/Ngừng bán.
Ban va chi hoan thien:
- Thu gon product card ban hang tren desktop.
- Giam gia truoc tong tien, hien thu / con phai thu ro rang.
- Them chon nhanh Thu 30%, 50%, Tra du; giu cac muc 100k/500k/1m khi phu hop.
- Khong hieu o trong cua 'Mot phan' la thu du.
- Canh bao tra 0, tra vuot tong, va thieu khach khi ghi no/giu hang.
- Khong cho Chot don/Luu offline khi so tien chua hop le, de domain van bao ve lan cuoi.
- Regression widget test khong ghi du lieu that.

CAI TREN WINDOWS:
1. Dung Codex/VS Code neu dang ghi source. Dong app VLXD dang chay.
2. Luu ZIP tai: D:\app\vlxd_app\VLXD_Nhom1_UIUX_AnToan_20261122.zip
3. Chay PowerShell:
   cd D:\app\vlxd_app
   Expand-Archive -LiteralPath .\VLXD_Nhom1_UIUX_AnToan_20261122.zip -DestinationPath .\.vlxd_group1_patch -Force
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\.vlxd_group1_patch\01_CAI_AN_TOAN.ps1
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\.vlxd_group1_patch\02_KIEM_TRA_VA_CHAY_DEMO.ps1

Muốn xem web thay Windows: o lenh cuoi them -Device chrome.
De thoat flutter run: nhan q trong PowerShell.

AN TOAN:
- Installer kiem tra SHA256 truoc khi sua file, tu choi khi source doi so voi ZIP nguon.
- Backup ban goc tai D:\app\vlxd_app\.vlxd_patch_backups\group1_...\lib\ui\sales.dart
- Du lieu Firebase/SQLite trong may khong duoc doc, sao chep hoac thay doi trong qua trinh cai.
- DEMO_MODE chi dung local/demo. Khong deploy live, khong tao setup.
- Khong chay git clean/reset. Khong copy toan bo ZIP source de de len du an.
- Moi kiem tra static (khong co Flutter SDK trong moi truong tao ZIP). MUST chay analyze/test tren Windows; neu loi khong su dung production.
