﻿param([string]$Project = 'D:\app\vlxd_app')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Get-Content -Raw -LiteralPath (Join-Path $bundle 'manifest.json') | ConvertFrom-Json
if (-not (Test-Path -LiteralPath (Join-Path $Project 'pubspec.yaml'))) {
    throw "Khong tim thay project Flutter tai $Project"
}

$jobs = @()
foreach ($item in $manifest.files) {
    $relative = [string]$item.relativePath
    if ($relative.Contains('..') -or [IO.Path]::IsPathRooted($relative)) {
        throw "Duong dan ban va khong hop le: $relative"
    }
    $source = Join-Path (Join-Path $bundle 'files') $relative
    $target = Join-Path $Project $relative
    if (-not (Test-Path -LiteralPath $source)) { throw "Ban va thieu file: $relative" }
    $patchHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash
    if ($patchHash -ne [string]$item.patchedSha256) {
        throw "Checksum cua ZIP sai: $relative"
    }
    $oldHash = if ($null -eq $item.originalSha256) { $null } else { [string]$item.originalSha256 }
    $exists = Test-Path -LiteralPath $target
    $currentHash = if ($exists) { (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash } else { $null }
    if ($currentHash -eq $patchHash) {
        Write-Host "Da cai, bo qua: $relative"
        continue
    }
    if (($null -eq $oldHash -and $exists) -or
        ($null -ne $oldHash -and $currentHash -ne $oldHash)) {
        throw "SOURCE DA DOI / CODEX DANG SUA: $relative. Da dung truoc khi ghi de. Khong duoc ep -Force."
    }
    $jobs += [pscustomobject]@{
        Relative = $relative
        Source = $source
        Target = $target
        Exists = $exists
        Expected = $patchHash
    }
}

if ($jobs.Count -eq 0) {
    Write-Host 'Ban va da cai day du. Khong co file nao bi sua.' -ForegroundColor Green
    exit 0
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $Project ".vlxd_patch_backups\group1_$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null
foreach ($job in $jobs) {
    if ($job.Exists) {
        $saveTo = Join-Path $backup $job.Relative
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $saveTo) | Out-Null
        Copy-Item -LiteralPath $job.Target -Destination $saveTo -ErrorAction Stop
    }
}

$written = @()
try {
    foreach ($job in $jobs) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $job.Target) | Out-Null
        $written += $job
        Copy-Item -LiteralPath $job.Source -Destination $job.Target -Force -ErrorAction Stop
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $job.Target).Hash -ne $job.Expected) {
            throw "Checksum sau khi sao chep khong khop: $($job.Relative)"
        }
        Write-Host "Cap nhat: $($job.Relative)"
    }
} catch {
    foreach ($job in $written) {
        if ($job.Exists) {
            Copy-Item -LiteralPath (Join-Path $backup $job.Relative) -Destination $job.Target -Force
        } elseif (Test-Path -LiteralPath $job.Target) {
            Remove-Item -LiteralPath $job.Target -Force
        }
    }
    throw "Cai dat that bai. Da thu phuc hoi source, backup: $backup. Chi tiet: $_"
}

Write-Host "HOAN TAT - Da sao luu code cu tai: $backup" -ForegroundColor Green
Write-Host 'Khong xoa, reset, migrate hay ghi du lieu Firebase/SQLite.'
Write-Host 'Buoc tiep theo: chay 02_KIEM_TRA_VA_CHAY_DEMO.ps1'
