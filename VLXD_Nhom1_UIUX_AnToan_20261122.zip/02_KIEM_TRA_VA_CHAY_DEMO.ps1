﻿param(
    [string]$Project = 'D:\app\vlxd_app',
    [ValidateSet('windows','chrome')][string]$Device = 'windows'
)
$ErrorActionPreference = 'Stop'

$flutter = 'D:\development\flutter\bin\flutter.bat'
if (-not (Test-Path -LiteralPath $flutter)) {
    $cmd = Get-Command flutter -ErrorAction SilentlyContinue
    if (-not $cmd) { throw 'Khong tim thay Flutter. Kiem tra D:\development\flutter\bin' }
    $flutter = $cmd.Source
}
if (-not (Test-Path -LiteralPath (Join-Path $Project 'pubspec.yaml'))) {
    throw "Khong tim thay project: $Project"
}
Push-Location $Project
try {
    Write-Host '1/3 - Flutter analyze (khong pub upgrade)' -ForegroundColor Cyan
    & $flutter analyze --no-pub
    if ($LASTEXITCODE -ne 0) { throw 'Analyze loi - chua chay demo. Gui log de kiem tra.' }

    Write-Host '2/3 - Flutter widget & business regression tests' -ForegroundColor Cyan
    & $flutter test --no-pub `
        test/sales_group1_ui_test.dart `
        test/sales_ux_test.dart `
        test/sales_product_actions_test.dart `
        test/cart_customer_test.dart `
        test/sales_offline_button_test.dart
    if ($LASTEXITCODE -ne 0) { throw 'Test loi - chua chay demo. Gui log de kiem tra.' }

    Write-Host "3/3 - Chay UI DEMO_MODE tren $Device" -ForegroundColor Green
    Write-Host 'DEMO_MODE - KHONG chot giao dich production.'
    & $flutter run -d $Device --dart-define=DEMO_MODE=true --no-pub
    if ($LASTEXITCODE -ne 0) { throw 'Khong chay duoc demo. Gui log de kiem tra.' }
} finally {
    Pop-Location
}
