param([string]$Project = 'D:\app\vlxd_app')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$target = Join-Path $Project 'test\cart_customer_test.dart'
if (-not (Test-Path -LiteralPath (Join-Path $Project 'pubspec.yaml'))) {
    throw "Khong tim thay du an Flutter: $Project"
}
if (-not (Test-Path -LiteralPath $target)) {
    throw "Khong tim thay file test: $target"
}

$bytes = [System.IO.File]::ReadAllBytes($target)
$hadBom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
$decoder = New-Object System.Text.UTF8Encoding($false, $true)
$content = $decoder.GetString($bytes)
if ($content.StartsWith([string][char]0xFEFF)) { $content = $content.Substring(1) }

$broken = '/ Match the Material widgets rendered by lib/ui/app.dart.'
$fixed = '// Match the Material widgets rendered by lib/ui/app.dart.'
$first = ($content -split "`r?`n", 2)[0]
if ($first -eq $fixed) {
    Write-Host 'Dong dau da dung. Khong can sua file.' -ForegroundColor Green
    exit 0
}
if ($first -ne $broken) {
    throw "Dong dau khong khop loi du kien, TU DUNG tranh ghi de thay doi cua Codex. Hien tai: $first"
}

$backupDir = Join-Path $Project ('.vlxd_patch_backups\fix_cart_comment_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$backup = Join-Path $backupDir 'cart_customer_test.dart'
Copy-Item -LiteralPath $target -Destination $backup -ErrorAction Stop

try {
    # Chi chen 1 dau / vao dau file, giu nguyen cac dong con lai va kieu xuong dong.
    $newContent = '/' + $content
    $encoding = New-Object System.Text.UTF8Encoding($hadBom)
    [System.IO.File]::WriteAllText($target, $newContent, $encoding)
    $verify = [System.IO.File]::ReadAllText($target, $decoder)
    if ($verify.StartsWith([string][char]0xFEFF)) { $verify = $verify.Substring(1) }
    $verifyFirst = ($verify -split "`r?`n", 2)[0]
    if ($verifyFirst -ne $fixed) { throw 'Khong xac minh duoc dong dau sau khi sua.' }
} catch {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    throw "Sua file that bai; da phuc hoi backup. Chi tiet: $_"
}

Write-Host 'DA SUA: dong 1 cua test\cart_customer_test.dart (/' + ' -> //).' -ForegroundColor Green
Write-Host "BACKUP: $backup"
Write-Host 'Khong sua source ung dung, du lieu, Firebase, SQLite.'
