VLXD APP - FIX LOI CU PHAP TEST CART (CHU THICH DONG 1)

Loi xac nhan tu log:
  test/cart_customer_test.dart:1
  / Match the Material widgets rendered by lib/ui/app.dart.

Dart can comment '//', khong phai '/'.
Ban va chi chen THEM MOT dau '/' o dau file, co kiem tra dong goc va backup.
Khong doi logic kinh doanh, khong sua lib/, database, Firebase hay schema.
Neu Codex da sua dong nay hoac source khac, script khong ghi de.

1) Chep ZIP vao D:\app\vlxd_app
2) Mo PowerShell:
   cd D:\app\vlxd_app
   Expand-Archive -LiteralPath '.\VLXD_Fix_Cart_Comment_20261122.zip' -DestinationPath '.\.vlxd_fix_cart_comment' -Force
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\.vlxd_fix_cart_comment\01_SUA_DONG_CHU_THICH_AN_TOAN.ps1'

3) Chay test rieng:
   flutter test --no-pub test/cart_customer_test.dart

4) Neu test rieng dat, tiep tuc:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\.vlxd_group1_patch\02_KIEM_TRA_VA_CHAY_DEMO.ps1'

NOTE: Chua chay Flutter SDK tren may Windows. Neu con loi, gui log tiep.
