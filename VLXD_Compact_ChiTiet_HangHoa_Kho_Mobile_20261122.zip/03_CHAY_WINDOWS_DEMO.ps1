$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
Push-Location $project
try {
    $flutter = 'flutter'
    if (!(Get-Command $flutter -ErrorAction SilentlyContinue)) {
        $flutter = 'D:\development\flutter\bin\flutter.bat'
    }
    & $flutter run -d windows --no-pub --dart-define=DEMO_MODE=true
    if ($LASTEXITCODE -ne 0) { throw 'Windows demo failed.' }
} finally { Pop-Location }
