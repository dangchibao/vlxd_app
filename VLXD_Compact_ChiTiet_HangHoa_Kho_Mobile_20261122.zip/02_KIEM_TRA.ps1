$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
Push-Location $project
try {
    $flutter = 'flutter'
    if (!(Get-Command $flutter -ErrorAction SilentlyContinue)) {
        $flutter = 'D:\development\flutter\bin\flutter.bat'
    }
    Write-Host '1/2: flutter analyze --no-pub' -ForegroundColor Cyan
    & $flutter analyze --no-pub
    if ($LASTEXITCODE -ne 0) { throw 'Analyze failed; do not continue to demo.' }
    Write-Host '2/2: compact details + existing group 2 tests' -ForegroundColor Cyan
    & $flutter test --no-pub test/compact_details_responsive_test.dart test/group2_compact_ui_test.dart
    if ($LASTEXITCODE -ne 0) { throw 'Widget test failed; send the log. Do not continue to demo.' }
    Write-Host 'All checks passed. Run 03_CHAY_WINDOWS_DEMO.ps1' -ForegroundColor Green
} finally { Pop-Location }
