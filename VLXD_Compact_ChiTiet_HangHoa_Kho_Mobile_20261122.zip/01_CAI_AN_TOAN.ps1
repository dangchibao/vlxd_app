$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$project = (Resolve-Path -LiteralPath (Join-Path $root '..')).Path
$manifest = Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json

function Sha([string]$path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant() }
function Dest([string]$rel) { return Join-Path $project ($rel -replace '/', [IO.Path]::DirectorySeparatorChar) }
function Source([string]$rel) { return Join-Path $root ($rel -replace '/', [IO.Path]::DirectorySeparatorChar) }
function Task([string]$rel,[string]$source,[string]$fromHash,[string]$toHash,[bool]$newFile) {
    $destination = Dest $rel
    $packageFile = Source $source
    if (!(Test-Path -LiteralPath $packageFile)) { throw "Missing patch: $source" }
    if ((Sha $packageFile) -ne $toHash) { throw "Patch SHA mismatch: $rel" }
    if (!(Test-Path -LiteralPath $destination)) {
        if (!$newFile) { throw "Missing source: $rel" }
        return [pscustomobject]@{ Rel=$rel; Dest=$destination; Src=$packageFile; Sha=$toHash; New=$true; Skip=$false }
    }
    $current = Sha $destination
    if ($current -eq $toHash) {
        return [pscustomobject]@{ Rel=$rel; Dest=$destination; Src=$packageFile; Sha=$toHash; New=$newFile; Skip=$true }
    }
    if ($newFile -or $current -ne $fromHash) {
        throw "SOURCE CHANGED: $rel. STOP to protect latest changes. Do not force overwrite."
    }
    return [pscustomobject]@{ Rel=$rel; Dest=$destination; Src=$packageFile; Sha=$toHash; New=$false; Skip=$false }
}

if (!(Test-Path -LiteralPath (Join-Path $project 'pubspec.yaml'))) { throw 'Not a Flutter project' }
$plan = New-Object System.Collections.ArrayList
foreach ($entry in $manifest.changes) {
    [void]$plan.Add((Task $entry.path $entry.package_path $entry.original_sha256 $entry.new_sha256 $false))
}
$opFile = Dest 'lib/ui/operations.dart'
if (!(Test-Path -LiteralPath $opFile)) { throw 'Missing operations.dart' }
$opHash = Sha $opFile
$variant = $manifest.operations_variants | Where-Object {
    $_.original_sha256 -eq $opHash -or $_.new_sha256 -eq $opHash
} | Select-Object -First 1
if ($null -eq $variant) { throw 'operations.dart has unknown changes; STOP. Send file to ChatGPT for merge.' }
[void]$plan.Add((Task 'lib/ui/operations.dart' $variant.package_path $variant.original_sha256 $variant.new_sha256 $false))
foreach ($entry in $manifest.new_files) {
    [void]$plan.Add((Task $entry.path $entry.package_path '' $entry.new_sha256 $true))
}

$pending = @($plan | Where-Object { -not $_.Skip })
if ($pending.Count -eq 0) {
    Write-Host 'Already installed. No files changed.' -ForegroundColor Green
    exit 0
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $project ".vlxd_patch_backups\compact_details_$stamp"
# Verify every candidate BEFORE modifying a single project file.
foreach ($item in $pending | Where-Object { -not $_.New }) {
    $save = Join-Path $backup ($item.Rel -replace '/', [IO.Path]::DirectorySeparatorChar)
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $save) | Out-Null
    Copy-Item -LiteralPath $item.Dest -Destination $save -ErrorAction Stop
}
$applied = New-Object System.Collections.ArrayList
try {
    foreach ($item in $pending) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $item.Dest) | Out-Null
        [void]$applied.Add($item)
        Copy-Item -LiteralPath $item.Src -Destination $item.Dest -Force -ErrorAction Stop
        if ((Sha $item.Dest) -ne $item.Sha) { throw "Copy mismatch: $($item.Rel)" }
    }
} catch {
    Write-Warning 'Installation failed. Restoring changed files...'
    foreach ($item in $applied) {
        if ($item.New) { Remove-Item -LiteralPath $item.Dest -Force -ErrorAction SilentlyContinue }
        else {
            $save = Join-Path $backup ($item.Rel -replace '/', [IO.Path]::DirectorySeparatorChar)
            Copy-Item -LiteralPath $save -Destination $item.Dest -Force -ErrorAction SilentlyContinue
        }
    }
    throw
}
Write-Host "PATCH INSTALLED. Backups: $backup" -ForegroundColor Green
Write-Host "Operations baseline: $($variant.name)" -ForegroundColor Cyan
Write-Host 'Only presentation files and one widget test changed. No DB/Firebase/data.'
