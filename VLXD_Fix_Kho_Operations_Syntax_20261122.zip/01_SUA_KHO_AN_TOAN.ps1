﻿$ErrorActionPreference = 'Stop'
$patchDir = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$project = (Resolve-Path -LiteralPath (Join-Path $patchDir '..')).Path
$source = Join-Path $project 'lib\ui\operations.dart'
if (!(Test-Path (Join-Path $project 'pubspec.yaml'))) { throw 'Sai thu muc du an Flutter.' }
if (!(Test-Path -LiteralPath $source)) { throw 'Khong tim thay operations.dart.' }
$manifest = Get-Content -LiteralPath (Join-Path $patchDir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$actual = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToUpperInvariant()
$done = $manifest.variants | Where-Object { $_.patched_sha256 -eq $actual } | Select-Object -First 1
if ($null -ne $done) { Write-Host 'Da cai ban sua truoc do, khong can ghi de.' -ForegroundColor Green; exit 0 }
$variant = $manifest.variants | Where-Object { $_.source_sha256 -eq $actual } | Select-Object -First 1
if ($null -eq $variant) { throw 'SOURCE CHANGED: operations.dart khac ban da kiem chung. TU DUNG de bao ve code moi.' }
$replacement = Join-Path $patchDir ($variant.file -replace '/', [IO.Path]::DirectorySeparatorChar)
if (!(Test-Path -LiteralPath $replacement)) { throw 'Thieu file ban va.' }
if (((Get-FileHash -LiteralPath $replacement -Algorithm SHA256).Hash.ToUpperInvariant()) -ne $variant.patched_sha256) {
    throw 'Checksum ban va khong dung; TU DUNG.'
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $project ".vlxd_patch_backups\fix_kho_syntax_$stamp"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$backup = Join-Path $backupDir 'operations.dart'
Copy-Item -LiteralPath $source -Destination $backup -ErrorAction Stop
try {
    Copy-Item -LiteralPath $replacement -Destination $source -Force -ErrorAction Stop
    if (((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToUpperInvariant()) -ne $variant.patched_sha256) {
        throw 'Checksum sau cai khong khop.'
    }
} catch {
    Copy-Item -LiteralPath $backup -Destination $source -Force -ErrorAction SilentlyContinue
    throw
}
Write-Host "DA SUA operations.dart ($($variant.variant))." -ForegroundColor Green
Write-Host "Sao luu: $backup" -ForegroundColor Cyan
Write-Host 'Khong sua database, Firebase, du lieu ban hang.'
